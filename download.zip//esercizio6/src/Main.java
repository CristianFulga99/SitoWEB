import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
         String nome, cognome;
         Scanner scan = new Scanner(System.in);
         System.out.println("Insert your name");
         nome = scan.nextLine();
         System.out.println("Insert your surname");
         cognome = scan.next();
          if (nome == null && cognome == null){
             System.out.println("PUT ALL YOUR DATA!");
             System.exit(3);
     }
         System.out.println("Select your language \n 1.)EN \n 2.)IT \n 3.)FR \n 4.)DE \n 5.)ES");
         String language = null;
         language = scan.next();
         switch (language){
             case "EN":
             System.out.println("Welcome, " +nome +" " + cognome+"!");
             break;
             case "IT":
             System.out.println("Benvenuto, " +nome +" " + cognome+"!");
             break;
             case "FR":
             System.out.println("Bienvenue, " +nome +" " + cognome+"!");
             break;
             case "DE":
             System.out.println("Willkommen, " +nome +" " + cognome+"!");
             break;
             case "ES":
             System.out.println("Bienvenida, " +nome +" " + cognome+"!");
             break;
             default:
             System.out.println("SORRY! LANGUAGE NOT FOUND!!");
         }

    }
}
