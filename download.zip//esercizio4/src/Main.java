import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
         String nome, cognome;
         Scanner scan = new Scanner(System.in);
         System.out.println("Ciao! Come ti chiami?");
         System.out.println("Inserisci il nome");
         nome = scan.nextLine();
         System.out.println("Inserisci il cognome");
         cognome = scan.next();
         System.out.println("Benvenuto "+ nome+ " " + cognome);
    }
}
