import java.util.Scanner;
import java.io.*;

public class Main {
    public static void main(String[] args) {
         Scanner scan = new Scanner(System.in);
            int i, a;
            System.out.println("Inserisci il numero per calcolare il quadrato..");
            i=scan.nextInt();
            a = i*i;
    
	    System.out.println("Il quadrato di " + i + " è " + a);
    }
}
