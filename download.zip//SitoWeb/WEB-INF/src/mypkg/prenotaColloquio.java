package mypkg;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class prenotaColloquio extends HttpServlet {
   @Override
   public void doGet(HttpServletRequest request, HttpServletResponse response)
               throws IOException, ServletException {
      response.setContentType("text/html;charset=UTF-8");
      PrintWriter out = response.getWriter();
 
      try {
         out.println("<!DOCTYPE html>");
         out.println("<html><head>");
         out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
         out.println("<title>Hello, World</title></head>");
         out.println("<body>");
         out.println("<h1>Ciao!<h1>");
         String username = request.getParameter("username");
         // Get null if the parameter is missing from query string.
         // Get empty string or string of white spaces if user did not fill in
         if (username == null) {
            out.println("<p>MISSING: USERNAME </p>");
         } else {
            out.println("<p>BENVENUTO " + username + "!!</p>");
         }
         out.println("</body>");
         out.println("</html>");
      } finally {
         out.close();  
      }
   }
 
}