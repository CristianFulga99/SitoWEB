package mypkg;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class gestioneAppuntamenti extends HttpServlet {
   @Override
   public void doGet(HttpServletRequest request, HttpServletResponse response)
               throws IOException, ServletException {
     
      response.setContentType("text/html;charset=UTF-8");
      PrintWriter out = response.getWriter();
 
      try {
         out.println("<!DOCTYPE html>");
         out.println("<html><head>");
         out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>");
         out.println("<title>Hello, World</title></head>");
         out.println("<body>");
         out.println("<form method='get' action='prenota'>");
         out.println("Insert your username");
         out.println("<input type='text' name='username'><br>");
         out.println("<br><input type='submit' value='Submit'>");
         out.println("<p>If you click Submit something magical will happen!</p>");
         out.println("</body>");
         out.println("</html>");
      } finally {
         out.close();
      }
   }
}