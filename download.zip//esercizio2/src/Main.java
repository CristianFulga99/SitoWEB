import java.util.Scanner;
import java.io.*;

public class Main {

    public static void main(String[] args) {
         Scanner scan = new Scanner(System.in);
            System.out.println("Inserisci un numero..");
            int i=scan.nextInt();
            System.out.println("Inserisci l'esponente..");           
            int a = scan.nextInt();
            double x = Math.pow(i,a);
            
	    System.out.println(i+ " elevato a " +a +" è uguale a " +x);
    }
}
