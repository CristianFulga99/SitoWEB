import java.util.Scanner;
import java.io.*;

public class Main {

    public static void main(String[] args) {
         Scanner scan = new Scanner(System.in);
            System.out.println("Inserisci un numero tra 0 e 10");
            int i=scan.nextInt();
            if (i<0 || i>10){
                System.out.println("Error");
            }
            System.out.println("Inserisci l'esponente..");           
            int a = scan.nextInt();
            double x = Math.pow(i,a);
            
	    System.out.println(i+ " elevato a " +a +" è uguale a " +x);
    }
}
